# ĐỀ THI THỐNG KÊ Y SINH — Bộ dữ liệu MINDSTROKE

**Dữ liệu:** `mindstroke_exam_data_wide.csv` (179 dòng, một dòng = một người tham gia) hoặc `mindstroke_exam_data_long.csv` (537 dòng, một dòng = một người × một mốc). Hai file chứa cùng dữ liệu.
**Dữ liệu là giả lập**, mô phỏng một thử nghiệm ngẫu nhiên có đối chứng 4 nhóm trên sinh viên khoẻ mạnh có stress cảm nhận cao (PSS-10 ≥ 20), can thiệp 8 tuần.

## Bối cảnh

Sinh viên được ngẫu nhiên hoá vào một trong bốn hoạt động, 45 phút/phiên, một phiên mỗi 3 ngày trong 8 tuần (tối đa 19 phiên):

| mã | nhóm |
|---|---|
| MS | Meaningful Sketching (vẽ hình có ý nghĩa) |
| MC | Mindful Calligraphy (thư pháp chú tâm) |
| MP | Music Practice (thực hành âm nhạc) |
| CG | Casual Gaming (trò chơi giải trí) |

Kết cục chính: điểm **PSS-10** (Perceived Stress Scale, 0–40, cao = stress nhiều) ở **tuần 8**, hiệu chỉnh theo baseline. Các so sánh định trước:
- **C1**: (MS + MC) so với (MP + CG) — so sánh chính
- **C2**: MS so với MC
- **C3**: MP so với CG

Khác biệt tối thiểu có ý nghĩa lâm sàng (MCID) được giả định là **3 điểm** PSS-10.

## Từ điển biến

| biến | kiểu | ý nghĩa |
|---|---|---|
| `id` | chuỗi | mã người tham gia |
| `arm` | MS / MC / MP / CG | nhóm được phân ngẫu nhiên |
| `site` | A / B / C | trung tâm tuyển chọn |
| `sex` | F / M | giới |
| `age` | số nguyên | tuổi (18–25) |
| `pss_w0` | 20–40 | PSS-10 tại baseline (tuần 0) |
| `pss_w4` | 0–40, có thể trống | PSS-10 tuần 4 |
| `pss_w8` | 0–40, có thể trống | PSS-10 tuần 8 (**kết cục chính**); trống = mất theo dõi |
| `sessions_completed` | 0–19 | số phiên đã hoàn thành |

Trong file *long*: cột `week` (0/4/8) và `pss` thay cho ba cột `pss_w0/w4/w8`.

## Câu hỏi

**Phần A — Mô tả và kiểm tra dữ liệu (20 điểm)**
1. Lập bảng mô tả baseline theo nhóm: n, tuổi (TB ± SD), tỉ lệ nữ, PSS-10 tuần 0 (TB ± SD), phân bố theo site. (8đ)
2. Có bao nhiêu người thiếu PSS tuần 8 trong mỗi nhóm? Tỉ lệ mất theo dõi có khác nhau giữa các nhóm không? Nêu kiểm định phù hợp và kết quả. (6đ)
3. Kiểm tra các nhóm có cân bằng về PSS baseline và giới hay không. Có nên dùng kiểm định ý nghĩa để "kiểm tra ngẫu nhiên hoá" không — vì sao? (6đ)

**Phần B — Phân tích trong nhóm và giữa nhóm (30 điểm)**
4. Với từng nhóm, tính thay đổi PSS (tuần 8 − tuần 0), trung bình và SD; kiểm định xem thay đổi có khác 0 không (nêu giả định và kết quả). (8đ)
5. Dùng ANOVA một yếu tố so sánh điểm thay đổi giữa 4 nhóm. Nêu giả thuyết, kiểm tra giả định phương sai đồng nhất, kết luận. Nếu giả định không thoả, dùng kiểm định thay thế nào? (10đ)
6. Giải thích vì sao ANCOVA (PSS tuần 8 ~ nhóm + PSS tuần 0) thường được ưu tiên hơn ANOVA trên điểm thay đổi trong thử nghiệm ngẫu nhiên. Thực hiện ANCOVA và báo cáo F của yếu tố nhóm, hệ số của PSS baseline. (12đ)

**Phần C — So sánh định trước và hiệu chỉnh đa so sánh (30 điểm)**
7. Từ mô hình ANCOVA, ước lượng hiệu số trung bình hiệu chỉnh cho C1, C2, C3 với khoảng tin cậy 95 %. (12đ)
8. C1 được kiểm định ở α = 0,05; C2 và C3 được hiệu chỉnh Holm. Tính p hiệu chỉnh cho C2, C3 và kết luận cho từng contrast. (8đ)
9. Tính Hedges g cho C1. Hiệu số C1 có vượt MCID không? Phân biệt "có ý nghĩa thống kê" và "có ý nghĩa lâm sàng" trong trường hợp này. (10đ)

**Phần D — Phân tích bổ sung (20 điểm)**
10. Định nghĩa "đáp ứng" = giảm ≥ 3 điểm PSS. Lập bảng tỉ lệ đáp ứng theo nhóm, kiểm định χ², và tính RR (hoặc OR) của MC so với CG kèm KTC 95 %. (10đ)
11. Số phiên hoàn thành có tương quan với mức thay đổi PSS không (trên người có dữ liệu tuần 8)? Vì sao phân tích này **không** cho phép kết luận nhân quả dù là trong RCT? (5đ)
12. Phân tích ở câu 6–7 chỉ dùng người có PSS tuần 8 (complete-case). Nêu giả định về cơ chế thiếu dữ liệu đang được đặt ra và một cách xử lý phù hợp với nguyên tắc ITT. (5đ)

*Yêu cầu: trình bày mã lệnh (R/Python/SPSS/Stata) hoặc công thức tính, và nêu rõ giả định của mỗi kiểm định.*
