# ĐÁP ÁN — Đề thi thống kê MINDSTROKE (dữ liệu giả lập, seed cố định)

Số liệu tính bằng Python (pandas/scipy/statsmodels); kết quả từ R/SPSS có thể lệch ở chữ số thập phân thứ hai do cách tính df/SE. Chấm theo phương pháp và cách diễn giải, không chỉ theo số.

## Phần A

**Câu 1 — Bảng mô tả baseline**

| nhóm | n | tuổi TB | % nữ | PSS W0 TB (SD) | site A/B/C |
|---|---|---|---|---|---|
| MS | 45 | 21.5 | 62.2 | 24.09 (3.15) | 22/16/7 |
| MC | 45 | 21.2 | 48.9 | 24.60 (3.03) | 13/20/12 |
| MP | 43 | 21.8 | 53.5 | 24.28 (2.55) | 18/20/5 |
| CG | 46 | 22.0 | 58.7 | 23.59 (2.70) | 18/16/12 |

**Câu 2 — Mất theo dõi tuần 8**: MS 3/45 (6.7 %), MC 3/45 (6.7 %), MP 4/43 (9.3 %), CG 2/46 (4.3 %). χ² (df 3) p ≈ 0.83 (hoặc Fisher exact vì ô nhỏ) → không có bằng chứng khác biệt. Người có tuần 8: 42 / 42 / 39 / 44 = 167.

**Câu 3 — Cân bằng baseline**: ANOVA PSS W0 theo nhóm F = 1.00, p = 0.40; χ² giới × nhóm p = 0.60. Điểm chấm chính: trong RCT, khác biệt baseline **chỉ do ngẫu nhiên**, nên kiểm định ý nghĩa cho "balance" không có logic (CONSORT khuyến cáo không làm); nên mô tả và hiệu chỉnh biến tiên lượng mạnh (PSS baseline) theo kế hoạch định trước.

## Phần B

**Câu 4 — Thay đổi W8 − W0 (complete-case) và paired t-test**

| nhóm | n | TB thay đổi | SD | t (df) | p | d_z |
|---|---|---|---|---|---|---|
| MS | 42 | −4.95 | 3.86 | 8.31 (41) | < 0.001 | 1.28 |
| MC | 42 | −6.62 | 4.10 | 10.46 (41) | < 0.001 | 1.61 |
| MP | 39 | −5.13 | 3.08 | 10.40 (38) | < 0.001 | 1.67 |
| CG | 44 | −3.27 | 4.60 | 4.72 (43) | < 0.001 | 0.71 |

Giả định: hiệu số phân phối xấp xỉ chuẩn (n ≈ 40, chấp nhận được). Lưu ý: giảm trong **mọi** nhóm kể cả CG — regression to the mean + hiệu ứng thời gian; vì vậy so sánh trong nhóm không chứng minh hiệu quả, cần so sánh giữa nhóm.

**Câu 5 — ANOVA một yếu tố trên điểm thay đổi**: F(3, 163) = 5.11, p = 0.002. Levene p = 0.07 (chấp nhận đồng nhất, ở mức biên). Thay thế: Welch ANOVA hoặc Kruskal–Wallis (H = 14.13, p = 0.003) — cùng kết luận.

**Câu 6 — ANCOVA** `pss_w8 ~ arm + pss_w0` (n = 167):
- Yếu tố nhóm: F(3, 162) = 5.08, p = 0.002.
- Hệ số PSS baseline: b = 1.03 (SE 0.11), p < 0.001.
- Hệ số so với CG: MC −3.37 (p < 0.001), MP −1.87 (p = 0.035), MS −1.70 (p = 0.051).
- Thêm sex + site: nhóm F(3, 159) = 4.63, p = 0.004; site p = 0.024; sex p = 0.48.

Vì sao ưu tiên ANCOVA: hiệu chỉnh baseline tăng power (giảm phương sai sai số), không giả định hệ số baseline = 1 như điểm thay đổi, ước lượng không chệch trong RCT và xử lý regression to the mean; điểm thay đổi là trường hợp đặc biệt của ANCOVA với β = 1.

## Phần C

**Câu 7 — Contrasts từ ANCOVA (có sex, site; df = 159)**

| contrast | hiệu số hiệu chỉnh | KTC 95 % | t | p |
|---|---|---|---|---|
| C1 (MS+MC) − (MP+CG) | **−1.62** | −2.82 đến −0.41 | −2.65 | 0.009 |
| C2 MS − MC | +1.57 | −0.15 đến +3.29 | 1.80 | 0.074 |
| C3 MP − CG | −1.59 | −3.31 đến +0.13 | −1.82 | 0.070 |

(Mô hình chỉ có baseline: C1 ≈ −1.6, kết luận không đổi.)
Trung bình hiệu chỉnh tuần 8: MS 19.1 · MC 17.6 · MP 19.2 · CG 20.8 (xấp xỉ).

**Câu 8 — Holm cho C2, C3**: sắp p tăng dần: C3 0.070 → × 2 = 0.141; C2 0.074 → × 1 = 0.074, lấy max với bước trước = 0.141. Cả hai p_Holm = 0.141 → không bác bỏ. Kết luận: C1 có ý nghĩa (nhóm thị giác–vận động giảm PSS nhiều hơn ≈ 1.6 điểm); C2, C3 không đủ bằng chứng.

**Câu 9 — Hedges g cho C1**: g = −0.41 (hiệu số / SD phần dư ≈ 3.9, nhân hệ số hiệu chỉnh). KTC của C1 (−2.82 đến −0.41) **nằm hoàn toàn trong dải ±3** → có ý nghĩa thống kê nhưng **không chắc đạt MCID**; cách diễn giải đúng: hiệu ứng nhỏ–trung bình, chưa chứng minh được khác biệt có ý nghĩa lâm sàng ở mức nhóm. Điểm chấm: phân biệt p-value với độ lớn hiệu ứng, và nêu vai trò của KTC so với MCID.

## Phần D

**Câu 10 — Đáp ứng (giảm ≥ 3 điểm)**

| nhóm | đáp ứng / n | % |
|---|---|---|
| MS | 33/42 | 78.6 |
| MC | 37/42 | 88.1 |
| MP | 30/39 | 76.9 |
| CG | 22/44 | 50.0 |

χ²(3) = 17.65, p < 0.001. MC so với CG: RR = 1.76 [1.28; 2.42]; OR = 7.40 [2.45; 22.4]. Lưu ý OR phóng đại khi kết cục phổ biến → ưu tiên RR/khác biệt nguy cơ (38 điểm %).

**Câu 11 — Số phiên và thay đổi PSS**: r = 0.01, p = 0.88 (Spearman ρ = 0.01) — không tương quan. Không nhân quả vì số phiên **không được ngẫu nhiên hoá**: là biến sau phân nhóm, chịu nhiễu bởi động cơ, thời gian rảnh, mức cải thiện sớm (người thấy đỡ có thể tập nhiều hơn hoặc ít hơn). Phân tích theo mức tuân thủ là quan sát, cần phương pháp riêng (CACE/instrumental variable).

**Câu 12 — Dữ liệu thiếu**: complete-case giả định MCAR (hoặc MAR có điều kiện trên biến trong mô hình). Cách phù hợp ITT: multiple imputation (có baseline, nhóm, tuần 4, site, giới) hoặc mixed model lặp lại (MMRM) dùng toàn bộ 179 người, kèm phân tích độ nhạy (vd. tipping-point) cho MNAR.

## Mã tham khảo (Python)

```python
import pandas as pd, statsmodels.formula.api as smf, statsmodels.api as sm
w = pd.read_csv("mindstroke_exam_data_wide.csv")
cc = w.dropna(subset=["pss_w8"])
m = smf.ols("pss_w8 ~ C(arm, Treatment('CG')) + pss_w0 + C(sex) + C(site)", data=cc).fit()
print(sm.stats.anova_lm(m, typ=2))
# contrast C1: (MS+MC)/2 − (MP+CG)/2, viết theo hệ số so với CG:
# = 0.5*(bMS + bMC) − 0.5*bMP − 0.5*0
print(m.t_test("0.5*C(arm, Treatment('CG'))[T.MS] + 0.5*C(arm, Treatment('CG'))[T.MC] - 0.5*C(arm, Treatment('CG'))[T.MP] = 0"))
```

Mã R tương đương: `m <- lm(pss_w8 ~ arm + pss_w0 + sex + site, data = cc); car::Anova(m); emmeans::emmeans(m, "arm") |> contrast(list(C1 = c(MS=.5, MC=.5, MP=-.5, CG=-.5), C2 = c(1,-1,0,0), C3 = c(0,0,1,-1)))` (thứ tự mức theo factor).

Hình tham khảo cho câu 7–9: `answer_fig3.png`; bảng contrasts đầy đủ: `answer_fig3_stats.csv`.
