#!/usr/bin/env bash
# Generate Figures 1–6 from one data set.  Usage: ./run_all.sh [data_dir] [out_dir]
# Order matters: Fig 4 before Fig 1 (Fig 1 needs cortisol-evaluable counts).
set -e
D=${1:-data/example}; O=${2:-outputs}; S=scripts
mkdir -p "$O"
python3 $S/fig2_design.py -o $O/fig2_design
python3 -W ignore $S/fig3_primary.py $D/data_pss.csv -o $O/fig3_primary -m 50
python3 -W ignore $S/fig4_cortisol.py $D/cortisol_diurnal.csv $D/cortisol_acute.csv -o $O/fig4_cortisol
python3 -W ignore $S/fig5_mechanisms.py $D/participants_wide.csv $D/mechanisms.csv $D/sessions.csv -o $O/fig5_mechanisms --boot 5000
python3 -W ignore $S/fig6_acute_adherence.py $D/participants_wide.csv $D/sessions.csv $D/acceptability.csv -o $O/fig6_acute_adherence
python3 $S/make_counts.py $D/participants_wide.csv $D/enrolment.json --cortisol $O/fig4_cortisol_indices.csv -o $O/counts.json
python3 $S/consort_flow.py $O/counts.json -o $O/fig1_consort
python3 $S/consort_flow.py $O/counts.json -o $O/fig1_consort_strict --strict
python3 - "$O" <<'PY'
import json, sys, pandas as pd
O=sys.argv[1]
c=json.load(open(f"{O}/counts.json")); a=pd.read_csv(f"{O}/fig6_acute_adherence_adherence.csv"); s=pd.read_csv(f"{O}/fig3_primary_summary.csv")
bad=False
for arm in ["MS","MC","MP","CG"]:
    w8=int(s[(s.arm==arm)&(s.week==8)]["n"].iloc[0]); pct=round(100*c[arm]["adherent_80"]/c[arm]["allocated"],1); p6=round(a[a.arm==arm]["pct_adherent"].iloc[0],1)
    ok=(w8==c[arm]["assessed_w8"]) and (pct==p6); bad|=not ok
    print(f"{arm}: W8 Fig1={c[arm]['assessed_w8']} Fig3={w8} | adherent Fig1={pct}% Fig6={p6}%  {'OK' if ok else 'MISMATCH'}")
sys.exit(1 if bad else 0)
PY
echo "done: fig1–fig6 in $O (cross-check passed)"
